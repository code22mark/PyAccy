cd /home/ssdev/PyAccy
./SkyFrog
